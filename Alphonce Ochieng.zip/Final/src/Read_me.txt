welcome to wordle 1.0
-By alphonce Ochieng